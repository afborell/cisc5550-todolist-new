from flask import Flask, jsonify, request
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect('todolist.db')
    return conn

@app.route("/api/items", methods=["GET"])
def get_items():
    db = get_db()
    cur = db.execute('SELECT what_to_do, due_date, status FROM entries')
    entries = cur.fetchall()
    db.close()
    tdlist = [dict(what_to_do=row[0], due_date=row[1], status=row[2]) for row in entries]
    return jsonify(tdlist)

@app.route("/api/items", methods=["POST"])
def add_item():
    new_item = request.json
    db = get_db()
    db.execute('INSERT INTO entries (what_to_do, due_date, status) VALUES (?, ?, ?)',
               [new_item['what_to_do'], new_item['due_date'], new_item['status']])
    db.commit()
    db.close()
    return jsonify({"status": "success"}), 201

@app.route("/api/items/<what_to_do>", methods=["PUT"])
def update_item(what_to_do):
    updated_status = request.json['status']
    db = get_db()
    db.execute('UPDATE entries SET status = ? WHERE what_to_do = ?',
               [updated_status, what_to_do])
    db.commit()
    db.close()
    return jsonify({"status": "success"})

@app.route("/api/items/<what_to_do>", methods=["DELETE"])
def delete_item(what_to_do):
    db = get_db()
    db.execute('DELETE FROM entries WHERE what_to_do = ?', [what_to_do])
    db.commit()
    db.close()
    return jsonify({"status": "success"})

if __name__ == "__main__":
    app.run(port=5001)
